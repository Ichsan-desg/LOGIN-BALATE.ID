<div class="container">

    <div class="card o-hidden border-0 shadow-lg col-lg-4 my-5 mx-auto ">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg">
                    <div class="p-5">
                        <div class="text-center">
                            <h1 class="title-card">BALATE.ID</h1>
                        </div>
                        <form class="user" method="post" action="<?= base_url('auth/registration'); ?>">
                            <div class="form-group">
                                <input style="border-radius: 5px; background-color: black ; opacity: 0.4; " type="text" class="form-control form-control-user" id="name" name="name" placeholder="Username" , value="<?= set_value('name'); ?>">
                                <?= form_error('name', ' <small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                            <div class="form-group">
                                <input style="border-radius: 5px; background-color: black ; opacity: 0.4; " type="password" class="form-control form-control-user" id="pass1" name="pass1" placeholder="Password">
                                <?= form_error('pass1', ' <small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                            <div class="form-group">
                                <input style="border-radius: 5px; background-color: black ; opacity: 0.4; " type="password" class="form-control form-control-user" id="pass2" name="pass2" placeholder="Confirm Password">
                            </div>
                            <div class="form-group">
                                <input style="border-radius: 5px; background-color: black ; opacity: 0.4; " type="tel" pattern="^\d{12}$" class="form-control form-control-user" id="numphone" name="numphone" placeholder="Phone Number">
                                <?= form_error('numphone', ' <small class="text-danger pl-3">', '</small>'); ?>
                            </div><br>
                            <button style="background: linear-gradient(to right, purple, brown); 
                            border: none;" type="submit" class="btn btn-primary btn-user btn-block">
                                SIGN UP
                            </button>
                        </form>
                        <hr>
                        <div class="text-center">
                            <a class="small" href="forgot-password.html">Forgot Password?</a>
                        </div>
                        <div class="text-center">
                            <a class="small" href="<?= base_url('auth'); ?>">Already have an account? Login!</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>