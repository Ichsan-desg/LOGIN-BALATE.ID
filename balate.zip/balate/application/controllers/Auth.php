<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller

{
    public function __construct()
    {
        parent::__construct();
        /*memanggil library form_validation */
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');
        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header');
            $this->load->view('auth/login');
            $this->load->view('templates/footer');
        } else {
            $this->_login();
        }
    }
    private function _login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $user = $this->db->get_where('user', ['name' => $username])->row_array();
        if ($user) {
            if (password_verify($password, $user['password'])) {
                redirect('testing'); // GANTI AJA REDIRECTNYA MAU DIARAHIN KEMANA SUKA-SUKA LU ///
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Wrong password!</div>');
                redirect('auth');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Username does not exist!</div>');
            redirect('auth');
        }
    }
    public function registration()
    {
        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('pass1', 'Password', 'required|trim|min_length[3]|matches[pass2]');
        $this->form_validation->set_rules('pass2', 'Password', 'required|trim|min_length[3]|matches[pass1]');



        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header');
            $this->load->view('auth/registration');
            $this->load->view('templates/footer');
        } else {
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'password' => password_hash($this->input->post('pass1'), PASSWORD_DEFAULT),
                'telepon' => $this->input->post('telepon'),
                'images' => 'default.jpg',
                'date_created' => time()
            ];

            $this->db->insert('user', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Congratulations your account has been crated! enjoy a 20% discount coupon on your first purchase!</div>');
            redirect('auth');
        }
    }
}
